"""
Version information for PyGraphviz, created during installation.

Do not add this file to the repository.

"""

__version__ = '1.3rc2'
__revision__ = None
__date__ = 'Fri Nov 07 23:03:15 2014'

